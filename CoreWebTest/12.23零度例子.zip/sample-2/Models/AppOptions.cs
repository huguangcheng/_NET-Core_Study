namespace StartupFilterSample.Models
{
    public class AppOptions
    {
        public string Option { get; set; } = "Option Default Value";
    }
}
